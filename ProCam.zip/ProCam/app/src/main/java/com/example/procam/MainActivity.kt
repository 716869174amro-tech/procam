package com.example.procam

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.media.ImageReader
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.AttributeSet
import android.util.Size
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.widget.*
import kotlin.math.min
import kotlin.math.pow

class AutoFitTextureView(c: Context, a: AttributeSet?) : TextureView(c, a) {
    private var ar = 16f / 9f
    fun setAspect(w: Int, h: Int) { ar = w.toFloat() / h; requestLayout() }
    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec); val h = MeasureSpec.getSize(hSpec)
        if (w / ar <= h) setMeasuredDimension(w, (w / ar).toInt())
        else setMeasuredDimension((h * ar).toInt(), h)
    }
}

data class Preset(val label: String, val w: Int, val h: Int, val fps: Int)

class MainActivity : Activity() {
    private lateinit var tv: AutoFitTextureView
    private lateinit var cm: CameraManager
    private lateinit var info: TextView
    private lateinit var swAe: Switch
    private lateinit var swAf: Switch
    private lateinit var seekIso: SeekBar
    private lateinit var seekShutter: SeekBar
    private lateinit var seekFocus: SeekBar
    private lateinit var spWb: Spinner
    private lateinit var spRes: Spinner
    private lateinit var btnRec: Button
    private lateinit var btnLens: Button

    private val bgThread = HandlerThread("cam").apply { start() }
    private val handler = Handler(bgThread.looper)

    private var ids = listOf<String>()
    private var idx = 0
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var chars: CameraCharacteristics? = null
    private var builder: CaptureRequest.Builder? = null
    private var previewSurface: Surface? = null
    private var jpegReader: ImageReader? = null

    private val presets = mutableListOf<Preset>()
    private var curPreset = 0
    private var previewSize = Size(1920, 1080)

    private var recorder: MediaRecorder? = null
    private var recPfd: ParcelFileDescriptor? = null
    @Volatile private var recording = false

    private val wbNames = listOf("Auto", "Incandescent", "Fluorescent", "Daylight", "Cloudy")
    private val wbModes = listOf(
        CameraMetadata.CONTROL_AWB_MODE_AUTO,
        CameraMetadata.CONTROL_AWB_MODE_INCANDESCENT,
        CameraMetadata.CONTROL_AWB_MODE_FLUORESCENT,
        CameraMetadata.CONTROL_AWB_MODE_DAYLIGHT,
        CameraMetadata.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT
    )

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.activity_main)
        tv = findViewById(R.id.texture); info = findViewById(R.id.info)
        swAe = findViewById(R.id.swAe); swAf = findViewById(R.id.swAf)
        seekIso = findViewById(R.id.seekIso); seekShutter = findViewById(R.id.seekShutter)
        seekFocus = findViewById(R.id.seekFocus)
        spWb = findViewById(R.id.spWb); spRes = findViewById(R.id.spRes)
        btnRec = findViewById(R.id.btnRec); btnLens = findViewById(R.id.btnLens)

        cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        ids = cm.cameraIdList.filter {
            cm.getCameraCharacteristics(it)
                .get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
                ?.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE) == true
        }

        spWb.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, wbNames)
        val change = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) { applyAll() }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        }
        seekIso.setOnSeekBarChangeListener(change)
        seekShutter.setOnSeekBarChangeListener(change)
        seekFocus.setOnSeekBarChangeListener(change)
        swAe.setOnCheckedChangeListener { _, _ -> applyAll() }
        swAf.setOnCheckedChangeListener { _, _ -> applyAll() }
        spWb.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { applyAll() }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        spRes.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos == curPreset || recording) return
                curPreset = pos; computePreviewSize()
                if (device != null) startPreview()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        btnLens.setOnClickListener {
            if (recording || ids.size < 2) return@setOnClickListener
            idx = (idx + 1) % ids.size; openCamera()
        }
        findViewById<Button>(R.id.btnShot).setOnClickListener { takePhoto() }
        btnRec.setOnClickListener { if (recording) stopRecording() else startRecording() }

        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { tryOpen() }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
    }

    override fun onResume() {
        super.onResume()
        val need = listOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1) else tryOpen()
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (r.isNotEmpty() && r.all { it == PackageManager.PERMISSION_GRANTED }) tryOpen()
        else Toast.makeText(this, "Camera & mic permissions are required", Toast.LENGTH_LONG).show()
    }

    override fun onPause() {
        if (recording) stopRecording()
        closeCamera()
        super.onPause()
    }

    override fun onDestroy() { bgThread.quitSafely(); super.onDestroy() }

    private fun tryOpen() {
        if (device == null && tv.isAvailable && ids.isNotEmpty() &&
            checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) openCamera()
    }

    // ---------- Camera lifecycle ----------
    @Suppress("MissingPermission")
    private fun openCamera() {
        closeCamera()
        val id = ids[idx]
        chars = cm.getCameraCharacteristics(id)
        setupPresets()
        btnLens.text = "Lens ${idx + 1}/${ids.size}"
        cm.openCamera(id, object : CameraDevice.StateCallback() {
            override fun onOpened(d: CameraDevice) { device = d; startPreview() }
            override fun onDisconnected(d: CameraDevice) { d.close(); device = null }
            override fun onError(d: CameraDevice, e: Int) { d.close(); device = null }
        }, handler)
    }

    private fun closeCamera() {
        try { session?.close() } catch (_: Exception) {}
        session = null
        device?.close(); device = null
        jpegReader?.close(); jpegReader = null
    }

    private fun setupPresets() {
        val c = chars!!
        val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val sizes = map.getOutputSizes(MediaRecorder::class.java).toList()
        val ranges = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES) ?: emptyArray()
        presets.clear()
        for ((n, w, h) in listOf(Triple("720p", 1280, 720), Triple("1080p", 1920, 1080), Triple("4K", 3840, 2160)))
            for (f in listOf(24, 30, 60))
                if (sizes.any { it.width == w && it.height == h } && ranges.any { it.lower <= f && it.upper >= f })
                    presets.add(Preset("$n ${f}fps", w, h, f))
        if (presets.isEmpty()) presets.add(Preset("1080p 30fps", 1920, 1080, 30))
        curPreset = presets.indexOfFirst { it.label == "1080p 30fps" }.coerceAtLeast(0)
        runOnUiThread {
            spRes.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, presets.map { it.label })
            spRes.setSelection(curPreset, false)
        }
        computePreviewSize()
    }

    private fun computePreviewSize() {
        val p = presets[curPreset]
        val map = chars!!.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        previewSize = map.getOutputSizes(SurfaceTexture::class.java)
            .filter { it.width * p.h == it.height * p.w && it.width <= 1920 }
            .maxByOrNull { it.width * it.height } ?: Size(1920, 1080)
        runOnUiThread { tv.setAspect(previewSize.width, previewSize.height) }
    }

    private fun sessionCb(ok: (CameraCaptureSession) -> Unit, fail: () -> Unit = {}) =
        object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(s: CameraCaptureSession) = ok(s)
            override fun onConfigureFailed(s: CameraCaptureSession) = fail()
        }

    private fun startPreview() {
        val d = device ?: return
        val st = tv.surfaceTexture ?: return
        st.setDefaultBufferSize(previewSize.width, previewSize.height)
        previewSurface?.release()
        val ps = Surface(st); previewSurface = ps
        jpegReader?.close()
        val map = chars!!.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val js = map.getOutputSizes(ImageFormat.JPEG).maxByOrNull { it.width * it.height }!!
        val reader = ImageReader.newInstance(js.width, js.height, ImageFormat.JPEG, 2)
        reader.setOnImageAvailableListener({ saveJpeg(it) }, handler)
        jpegReader = reader
        try { session?.close() } catch (_: Exception) {}
        d.createCaptureSession(listOf(ps, reader.surface), sessionCb({ s ->
            session = s
            builder = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply { addTarget(ps) }
            applyAll()
        }), handler)
    }

    // ---------- Manual controls ----------
    private fun isoVal(): Int {
        val r = chars!!.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)!!
        return r.lower + ((r.upper - r.lower) * seekIso.progress / 100.0).toInt()
    }

    private fun expNs(): Long {
        val r = chars!!.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)!!
        val denom = 30.0 * (8000.0 / 30.0).pow(seekShutter.progress / 100.0)
        val fps = presets.getOrNull(curPreset)?.fps ?: 30
        val ns = min((1e9 / denom).toLong(), (1e9 / fps).toLong())
        return ns.coerceIn(r.lower, r.upper)
    }

    private fun focusDiopter(): Float {
        val min = chars!!.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        return min * seekFocus.progress / 100f
    }

    private fun applySettings(b: CaptureRequest.Builder, still: Boolean) {
        val c = chars ?: return
        b.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
        if (swAe.isChecked) {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF)
            b.set(CaptureRequest.SENSOR_SENSITIVITY, isoVal())
            b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, expNs())
        } else b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON)

        val minFocus = c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        if (swAf.isChecked && minFocus > 0f) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_OFF)
            b.set(CaptureRequest.LENS_FOCUS_DISTANCE, focusDiopter())
        } else b.set(CaptureRequest.CONTROL_AF_MODE,
            if (recording) CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO
            else CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE)

        b.set(CaptureRequest.CONTROL_AWB_MODE, wbModes[spWb.selectedItemPosition.coerceAtLeast(0)])

        if (!still) {
            val fps = presets.getOrNull(curPreset)?.fps ?: 30
            val ranges = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
            val r = ranges?.firstOrNull { it.lower == fps && it.upper == fps }
                ?: ranges?.firstOrNull { it.upper == fps }
            if (r != null) b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, r)
        }
        runOnUiThread {
            info.text = if (swAe.isChecked) "ISO ${isoVal()}  1/${(1e9 / expNs()).toInt()}s" else "Auto exposure"
        }
    }

    private fun applyAll() {
        val b = builder ?: return
        try {
            applySettings(b, false)
            session?.setRepeatingRequest(b.build(), null, handler)
        } catch (_: Exception) {}
    }

    // ---------- Orientation ----------
    @Suppress("DEPRECATION")
    private fun orient(): Int {
        val sens = chars!!.get(CameraCharacteristics.SENSOR_ORIENTATION)!!
        val rot = windowManager.defaultDisplay.rotation * 90
        val front = chars!!.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
        return if (front) (sens + rot) % 360 else (sens - rot + 360) % 360
    }

    // ---------- Photo ----------
    private fun takePhoto() {
        val d = device ?: return; val s = session ?: return; val r = jpegReader ?: return
        if (recording) return
        try {
            val b = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
            b.addTarget(r.surface)
            applySettings(b, true)
            b.set(CaptureRequest.JPEG_ORIENTATION, orient())
            b.set(CaptureRequest.JPEG_QUALITY, 100.toByte())
            s.capture(b.build(), null, handler)
        } catch (_: Exception) {}
    }

    private fun saveJpeg(reader: ImageReader) {
        val img = reader.acquireNextImage() ?: return
        val buf = img.planes[0].buffer
        val bytes = ByteArray(buf.remaining()).also { buf.get(it) }
        img.close()
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "IMG_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ProCam")
        }
        contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)?.let { uri ->
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            runOnUiThread { Toast.makeText(this, "Photo saved", Toast.LENGTH_SHORT).show() }
        }
    }

    // ---------- Video ----------
    private fun startRecording() {
        val d = device ?: return
        val p = presets[curPreset]
        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "VID_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ProCam")
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v) ?: return
        val pfd = contentResolver.openFileDescriptor(uri, "w") ?: return
        recPfd = pfd
        val rec = MediaRecorder().apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setOutputFile(pfd.fileDescriptor)
            setVideoEncodingBitRate(min(100_000_000L, p.w.toLong() * p.h * p.fps / 4).toInt())
            setVideoFrameRate(p.fps)
            setVideoSize(p.w, p.h)
            setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setAudioEncodingBitRate(192_000)
            setAudioSamplingRate(48_000)
            setOrientationHint(orient())
            prepare()
        }
        recorder = rec
        try { session?.close() } catch (_: Exception) {}
        val ps = previewSurface ?: return
        d.createCaptureSession(listOf(ps, rec.surface), sessionCb({ s ->
            session = s
            builder = d.createCaptureRequest(CameraDevice.TEMPLATE_RECORD).apply {
                addTarget(ps); addTarget(rec.surface)
            }
            recording = true
            applyAll()
            rec.start()
            runOnUiThread { btnRec.text = "STOP"; spRes.isEnabled = false; btnLens.isEnabled = false }
        }, { cleanupRecorder(); startPreview() }), handler)
    }

    private fun stopRecording() {
        recording = false
        try { session?.stopRepeating(); session?.abortCaptures() } catch (_: Exception) {}
        try { recorder?.stop() } catch (_: Exception) {}
        cleanupRecorder()
        runOnUiThread {
            btnRec.text = "REC"; spRes.isEnabled = true; btnLens.isEnabled = true
            Toast.makeText(this, "Video saved", Toast.LENGTH_SHORT).show()
        }
        startPreview()
    }

    private fun cleanupRecorder() {
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { recPfd?.close() } catch (_: Exception) {}
        recPfd = null
    }
}
