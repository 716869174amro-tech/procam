ProCam - open this folder in Android Studio (Koala or newer), let Gradle sync, plug in a phone with USB debugging, press Run.
Min Android 10 (API 29). Photos -> Pictures/ProCam, videos -> Movies/ProCam.
